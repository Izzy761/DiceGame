﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CrapsDiceGame
{
    public partial class Players : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CrapsGame;");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int id = 0;
        public Players()
        {
            InitializeComponent();
            LoadPlayers();
        }

        private void LoadPlayers()
        {            
            con.Open();
            DataTable dt = new DataTable();
            string sql = @"Select Id,PlayerName from Players";            
            adapt = new SqlDataAdapter(sql, con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void CleanUp()
        {
            id = 0;
            txtPlayerName.Text = "";
        }

        private void btnCreatePlayer(object sender, EventArgs e)
        {//Insert a new player if it does not exist into a local db
            if (!String.IsNullOrWhiteSpace(txtPlayerName.Text))
            {
                try
                {
                    con.Open();
                    
                    string sql = @"if NOT EXISTS (Select * from Players WHERE PlayerName = @name)
                    begin
                    Insert into Players(PlayerName) values(@name)
                    Insert into PlayerHistory(PlayerID) Select Max(id) from Players
                    end";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@name", txtPlayerName.Text);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                    LoadPlayers();
                    CleanUp();
                }
                catch(Exception ex)
                {
                    lblError.Text = ex.ToString();
                }
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString()))
            {
                id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                txtPlayerName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
        }

        private void StartGame_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                (new Game(id)).Show();
                this.Hide();
            }
            else
            {
                lblError.Text = "Please Select a player below to start a game or to pick up where you left off.";
            }
            
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                con.Open();
                string sql = @"delete PlayerHistory where PlayerID = @ID";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                LoadPlayers();
                CleanUp();
            }
            else
            {
                lblError.Text = "Please Select a player below to start a game or to pick up where you left off.";
            }            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                con.Open();
                string sql = @"delete PlayerHistory where PlayerID = @ID delete Players where Id = @id";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                LoadPlayers();
                CleanUp();
            }
            else
            {
                lblError.Text = "Please Select a player below to start a game or to pick up where you left off.";
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                con.Open();
                string sql = @"update Players set PlayerName = @name where ID = @ID";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@name", txtPlayerName.Text);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                LoadPlayers();
                CleanUp();
            }
            else
            {
                lblError.Text = "Please Select a player below to start a game or to pick up where you left off.";
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
