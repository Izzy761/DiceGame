﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CrapsDiceGame
{
    public partial class Game : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CrapsGame;");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int PlayerID = 0;
        int point = 0;
        public Game(int ID)
        {
            InitializeComponent();
            PlayerID = ID;
            LoadData();
        }
        private void ClearDice()
        {
            point = 0;
            //txtRoll.Text = "";
            //txtTotal.Text = "";
        }
        private void LoadData()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                string sql = @"Select * from vw_PlayerHistory where ID = @id";
                adapt = new SqlDataAdapter(sql, con);
                adapt.SelectCommand.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@id",
                    Value = PlayerID
                });
                adapt.Fill(dt);
                txtWinLose.Text = dt.Rows[0][3].ToString();
                txtNumRolls.Text = dt.Rows[0][2].ToString();
                con.Close();
            }
            catch 
            {

            }
        }
        //wins 7, 11
        //craps 2, 3, 12
        //point 4, 5, 6, 8, 9, 10, 
        //lose point and 7 
        private void btnRollDice_OnClick(object sender, EventArgs e)
        {
            Random Roll = new Random();
            int Dice1 = Roll.Next(1, 6);
            int Dice2 = Roll.Next(1, 6);
            txtRoll.Text = Dice1 + ", " + Dice2;
            txtTotal.Text = (Dice1 + Dice2).ToString();
            Rules(Dice1 + Dice2);
        }

        private void Rules(int rolls)
        {
            if (point == 0)
            {
                if (rolls == 7 || rolls == 11)
                {
                    //Win message text
                    txtResult.Text = "Win";
                    Win(rolls, point);
                }
                else if (rolls == 2 || rolls == 3 || rolls == 12)
                {
                    //Craps message text
                    txtResult.Text = "Craps";
                    Lose(rolls, point);
                }
                else
                {
                    //Point message text                
                    point = rolls;
                    txtResult.Text = "Point " + point;
                    Points(rolls, point);
                }
            }
            else if (rolls == 7 )
            {
                txtResult.Text = "Lost";
                Lose(rolls, point);
                ClearDice();
            }
            else if (point == rolls || rolls != 7)
            {
                txtResult.Text = "Win";
                Win(rolls, point);
                ClearDice();
            }
        }

        private void Win(int roll, int point)
        {           
            try
            {
                con.Open();
                string sql = @"Insert into PlayerHistory(PlayerID,Roll,Point,Result) values(@id,@roll,@point,@result)";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@id", PlayerID);
                cmd.Parameters.AddWithValue("@roll", roll);
                cmd.Parameters.AddWithValue("@point", point);
                cmd.Parameters.AddWithValue("@result", "Win");
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                ClearDice();
                LoadData();
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.ToString();
            }
        }
        private void Lose(int roll, int point)
        {
            
            try
            {
                con.Open();
                string sql = @"Insert into PlayerHistory(PlayerID,Roll,Point,Result) values(@id,@roll,@point,@result)";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@id", PlayerID);
                cmd.Parameters.AddWithValue("@roll", roll);
                cmd.Parameters.AddWithValue("@point", point);
                cmd.Parameters.AddWithValue("@result", "Lose");
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                ClearDice();
                LoadData();
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.ToString();
            }
        }
        private void Points(int roll, int point)
        {
            try
            {
                con.Open();
                string sql = @"Insert into PlayerHistory(PlayerID,Roll,Point,Result) values(@id,@roll,@point,null)";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@id", PlayerID);
                cmd.Parameters.AddWithValue("@roll", roll);
                cmd.Parameters.AddWithValue("@point", point);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                LoadData();
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.ToString();
            }
        }

        private void btnMM_Click(object sender, EventArgs e)
        {
            (new Players()).Show();
            PlayerID = 0;
            this.Hide();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }
    }
}
